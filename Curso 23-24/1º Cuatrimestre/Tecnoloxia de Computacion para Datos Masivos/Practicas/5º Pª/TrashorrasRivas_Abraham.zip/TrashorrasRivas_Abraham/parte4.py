from __future__ import print_function, division
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
from pyspark.sql.window import Window
import sys

def read_parquet_files(spark, citas_path, info_path):
    # Leemos los archivos Parquet y los devolvemos como DataFrames.
    df_citas = spark.read.parquet(citas_path)
    df_info = spark.read.parquet(info_path)
    return df_citas, df_info

def join_dataframes(df_citas, df_info):
    # Realizamos un join entre los DataFrames de citas y de informacion.
    df_info_renamed = df_info.withColumnRenamed("NPatente", "NPatente_Info")
    df_joined = df_citas.join(df_info_renamed, df_citas['NPatente'] == df_info_renamed['NPatente_Info'], 'inner')
    return df_joined.select('Pais', 'Anho', 'NPatente', 'nCitas')

def filter_by_countries(df, countries):
    # Filtramos el DataFrame por los paises especificados.
    return df.filter(f.col('Pais').isin(countries.split(',')))

def calculate_rank(df):
    # Calculamos el rango de patentes por pais y anho.
    window_spec = Window.partitionBy('Pais', 'Anho').orderBy(f.col('nCitas').desc())
    return df.withColumn("Rango", f.dense_rank().over(window_spec))

def main():
    if len(sys.argv) != 5:
        print("Uso: <script> <citations_path> <info_path> <country_list> <output_path>")
        sys.exit(-1)

    df_citas_path, df_info_path, country_list, output_path = sys.argv[1:5]

    spark = SparkSession.builder.appName("Analisis de patente").getOrCreate()
    spark.sparkContext.setLogLevel("FATAL")

    df_citas, df_info = read_parquet_files(spark, df_citas_path, df_info_path)
    df_joined = join_dataframes(df_citas, df_info)
    df_filtered = filter_by_countries(df_joined, country_list)
    df_ranked = calculate_rank(df_filtered)

    df_final = df_ranked.orderBy('Pais', 'Anho', 'nCitas', ascending=[True, True, False])
    df_final.coalesce(1).write.csv(output_path, mode='overwrite', header=True)

    spark.stop()

if __name__ == "__main__":
    main()
