import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, sum, avg, max

def cargar_codigos_pais(path):
    # Cargamos los codigos de los paises desde country_codes.txt en un diccionario.
    with open(path, 'r') as file:
        return {line.split()[0]: line.split()[1].rstrip('\n') for line in file}

def procesar_datos(df_citas, df_info, codigos_pais, sc):
    # Procesamos los datos de citas y patentes, realizando un join y calculando las estadisticas.
    broadcast_codigos_pais = sc.broadcast(codigos_pais)

    df_citas = df_citas.withColumnRenamed("NPatente", "NPatente_Info")
    df_joined = df_citas.join(df_info, col('NPatente_Info') == df_info['NPatente'], 'inner').select('NPatente', 'nCitas', 'Pais', 'Anho')
    
    # Sustituimos los codigos de los paises por los nombres completos
    df_joined = df_joined.rdd.map(lambda x: (x[0], x[1], broadcast_codigos_pais.value.get(x[2]), x[3])).toDF(['NPatente', 'nCitas', 'Pais', 'Anho'])

    # Agregamos por pais y anho
    df_agregado = df_joined.groupBy(col('Pais'), col('Anho')).agg(
        count('NPatente').alias('NumPatentes'),
        sum('nCitas').alias('TotalCitas'),
        avg('nCitas').alias('MediaCitas'),
        max('nCitas').alias('MaxCitas')
    ).orderBy('Pais', 'Anho')

    return df_agregado

def main():
    if len(sys.argv) != 5:
        print("Uso: <script> <path_df_citas> <path_df_info> <path_codigos_pais> <path_salida>")
        sys.exit(-1)

    path_df_citas, path_df_info, path_codigos_pais, path_salida = sys.argv[1:5]

    spark = SparkSession.builder.appName("Analisis de Patentes").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    sc = spark.sparkContext

    codigos_pais = cargar_codigos_pais(path_codigos_pais)
    df_citas = spark.read.parquet(path_df_citas)
    df_info = spark.read.parquet(path_df_info)

    df_resultado = procesar_datos(df_citas, df_info, codigos_pais, sc)
    df_resultado.coalesce(1).write.csv(path_salida, mode='overwrite', header=True)

    print("Script completado. Los datos procesados se han guardado en: %s" % path_salida)

    spark.stop()

if __name__ == "__main__":
    main()
