import sys
from pyspark import SparkContext, SparkConf
from operator import add

def procesar_archivo(ruta_archivo, num_particiones):
    # Procesamos el archivo para obtener el numero de patentes por pais y anho.
    rdd = sc.textFile(ruta_archivo, num_particiones)
    
    # Eliminamos la cabecera y las comillas en el codigo del pais
    rdd_limpio = (rdd.filter(lambda linea: not linea.startswith("\"PATENT\""))
                    .map(lambda linea: linea.replace('\"', '')))

    # Extraemos el pais(campo 5) y el anho(campo 2) y contamos las patentes(campo 1)
    rdd_pais_anho = (rdd_limpio.map(lambda linea: linea.split(","))
                               .map(lambda campos: (campos[4], campos[1]))
                               .map(lambda pais_anho: (pais_anho, 1))
                               .reduceByKey(add))

    # Reorganizamos y ordenamos por pais y anho
    rdd_organizado = (rdd_pais_anho.map(lambda x: (x[0][0], [(x[0][1], x[1])]))
                                    .reduceByKey(lambda a, b: sorted(a + b, key=lambda x: x[0]))
                                    .sortByKey())

    return rdd_organizado

def guardar_rdd(rdd, ruta_salida):
    # Guardamos el RDD en la ruta especificada.
    rdd.saveAsTextFile(ruta_salida)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso correcto: <script> <ruta_entrada> <ruta_salida>")
        sys.exit(-1)

    ruta_entrada, ruta_salida = sys.argv[1], sys.argv[2]

    conf = SparkConf().setAppName("Conteo Patentes por Pais y Anho")
    sc = SparkContext(conf=conf)
    sc.setLogLevel("ERROR")

    rdd_resultado = procesar_archivo(ruta_entrada, 8)
    guardar_rdd(rdd_resultado, ruta_salida)

    print("El proceso ha finalizado. Los resultados se han guardado en: {}".format(ruta_salida))
    sc.stop()
