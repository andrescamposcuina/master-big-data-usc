import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

def process_citations(input_path, output_path):
    """Procesamos el archivo de citaciones y guardamos el resultado."""
    df = spark.read.csv(input_path, header=True, inferSchema=True)
    result = df.groupBy("CITED").agg({'*': 'count'}).withColumnRenamed("CITED", "NPatente").withColumnRenamed("count(1)", "nCitas").sort("NPatente")
    result.write.parquet(output_path, mode="overwrite", compression="gzip")
    return result.rdd.getNumPartitions()

def process_patents(input_path, output_path):
    """Procesamos el archivo de patentes y guardamos el resultado."""
    df = spark.read.csv(input_path, header=True, inferSchema=True, nullValue='null')
    result = df.select(col("PATENT").alias("NPatente"), col("COUNTRY").alias("Pais"), col("GYEAR").alias("Anho")).orderBy("NPatente")
    result.write.parquet(output_path, mode="overwrite", compression="gzip")
    return result.rdd.getNumPartitions()

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Formato entrada: <script> <cite75_99_path> <apat63_99_path> <citations_output> <patents_output>")
        sys.exit(-1)

    spark = SparkSession.builder.appName("Patent Data Processing").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    cite75_99_path, apat63_99_path, citations_output, patents_output = sys.argv[1:5]

    num_partitions_citations = process_citations(cite75_99_path, citations_output)
    print("Numero de particiones en el DataFrame dfCitas: %d" % num_partitions_citations)

    num_partitions_patents = process_patents(apat63_99_path, patents_output)
    print("Numero de particiones en el DataFrame dfInfo: %d" % num_partitions_patents)


    spark.stop()

