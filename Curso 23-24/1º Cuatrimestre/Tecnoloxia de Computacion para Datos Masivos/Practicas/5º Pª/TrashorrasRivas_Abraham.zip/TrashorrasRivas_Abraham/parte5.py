from __future__ import print_function, division
from pyspark.sql import SparkSession
import pyspark.sql.functions as f
from pyspark.sql.window import Window
import sys

def read_parquet_file(spark, file_path):
    # Leemos un archivo Parquet y devolvemos un DataFrame.
    return spark.read.parquet(file_path)

def calculate_decade(df):
    # Calculamos la decada para cada anho en el DataFrame.
    return df.withColumn('Decada', (f.col('Anho') - (f.col('Anho') % 10)))

def count_patents_by_decade(df):
    # Contamos las patentes por pais y por decada.
    return df.groupBy('Pais', 'Decada').count()

def calculate_difference(df):
    # Calculamos la diferencia del numero de patentes con respecto a la decada anterior.
    window = Window.partitionBy('Pais').orderBy('Decada')
    previous_count = f.lag(f.col('count'), 1).over(window)
    df_with_diff = df.withColumn("Dif", (f.col('count') - previous_count))
    return df_with_diff.fillna(0, subset=['Dif'])

def process_data(spark, input_path, output_path):
    # Procesamos los datos de las patentes y escribimos el resultado en un archivo CSV.
    df_info = read_parquet_file(spark, input_path)
    df_with_decade = calculate_decade(df_info)
    df_by_decade = count_patents_by_decade(df_with_decade)
    df_final = calculate_difference(df_by_decade)

    df_final.select(
        'Pais',
        'Decada',
        f.col('count').alias('NPatentes'),
        f.coalesce('Dif', f.lit(0)).alias('Dif')
    ).orderBy('Pais', 'Decada').coalesce(1).write.csv(output_path, mode='overwrite', header=True)

def main():
    if len(sys.argv) != 3:
        print("Uso: <script> <input_parquet_path> <output_csv_path>")
        sys.exit(-1)

    input_path, output_path = sys.argv[1], sys.argv[2]

    spark = SparkSession.builder.appName("Analisis de patente por decada").getOrCreate()
    spark.sparkContext.setLogLevel("FATAL")

    process_data(spark, input_path, output_path)

    spark.stop()

if __name__ == "__main__":
    main()
