#!/usr/bin/env python
# coding: utf-8

# ### PRÁCTICA 1: Extrayendo y analizando web data sobre adicción al juego
# Por Abraham Trashorras Rivas

# El primer paso en esta práctica es la extración de datos de la web de forma automatizada. Para este fin he empleado las librerias de Scrapy y BeautifulSoup, las cuales me permiten crear "arañas" las cuales son pedazos de codigo autónomo que recorreran la web especificada extrallendo la información que les señalamos.
# 
# En este caso nuestra araña se llamará LudopatiaSpider y recabara el título y cuerpo de todas las publicaciones en la web https://www.ludopatia.org/forum/forum_topics.asp?FID=1, guardando los datos en formato json en el archivo ludopatia.json
# 

# In[3]:


# Importamos las librerias necesarias para definir la araña
from bs4 import BeautifulSoup, Comment
import re
import json
import scrapy
from scrapy.crawler import CrawlerProcess


# In[4]:


# Aquí definimos la araña que estará formada por dos funciones parse y parse_post
class LudopatiaSpider(scrapy.Spider):
    name = "LudopatiaSpider"
    start_urls = ['https://www.ludopatia.org/forum/forum_topics.asp?FID=1&PN=1']

    # Esta función recorre la web hasta la última página, extrayendo las url de las publicaciones
    def parse(self, response):
        # Extraemos las URLs de cada publicación
        for post in response.css('td[class="text"] a[href^="forum_posts.asp"]::attr(href)').extract():
            post_url = response.urljoin(post)
            yield scrapy.Request(url=post_url, callback=self.parse_post)

        # Avanzamos a la siguiente página
        next_page = response.css('a[href^="forum_topics.asp"]:contains("Siguiente")::attr(href)').get()
        if next_page:
            next_page_url = response.urljoin(next_page)
            yield scrapy.Request(url=next_page_url, callback=self.parse)

    # Esta función extrae el título y cuerpo de la publicación y los guarda en formato json
    def parse_post(self, response):
        # Extraemos el título de la publicación
        title_text = response.css('span.lgText:first-of-type::text').get()
        if title_text:
            title = title_text.replace("Tema: ", "").strip()
            
        # La extracción del cuerpo es mas compleja debido a que comparte estructura con la de los comentarios
        # Primero obtenemos todos los elementos que forman el cuerpo
        nodes_after_table = response.xpath('//td[@class="text"]/table/following-sibling::node()').extract()

        # Extraemos unicamente el texto que nos interesa
        body = []
        stop_markers = ["<span", "<!-- Message body ''\"\" -->"]
        for node in nodes_after_table:
            if any(marker in node for marker in stop_markers):
                break
            body.append(node)

        # Unimos todos los pedazos de texto
        body_html = ''.join(body)

        # Lo formateamos con BeautifulSoup para eliminar elementos html
        soup = BeautifulSoup(body_html, 'lxml')

        # Extraemos el texto con el formateo adecuado
        cleaned_body = soup.get_text(separator=' ', strip=True)
        
        # Lo fusionamos en un solo elemento
        merged_content = ''.join(cleaned_body)

        # Necesitamos limpiarlo de elementos html otra vez para eliminar etiquetas simples como <br>
        soup = BeautifulSoup(merged_content, 'lxml')
        body = soup.get_text(separator=" ")

        # Devolvemos el elemento json formateado
        yield {
            'title': title,
            'body': body
        }


# In[3]:


# Definimos las propiedades de la araña para que extraiga con exito la información
process = CrawlerProcess({
    'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'FEED_FORMAT': 'json',
    'FEED_URI': 'ludopatia.json',
    'FEED_EXPORT_ENCODING': 'utf-8',
    'COOKIES_ENABLED': False
})

# Iniciamos la araña
process.crawl(LudopatiaSpider)
process.start() 


# Ahora que tenemos la información guardada en el documento ludopatia.json, podemos importarla, estudiar su tamaño e imprimir el título del primer elemento

# In[44]:


# Función para cargar el archivo JSON
def load_json_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        return json.load(file)

# Uso de la función
data = load_json_file('ludopatia.json')

print(f"Número de documentos: {len(data)}")
print(f"Campos de los documentos: {data[0].keys()}")
print(f"Titulo del primer elemento: {data[0]['title']}")


# Ahora vamos a emplear la librería scikit-learn para estudiar la frecuencia de las palabras en el conjunto de documentos

# In[50]:


from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
import nltk
from nltk.corpus import stopwords


# In[49]:


# Nos preparamos para filtrar aquellas palabras no relevantes, o stopwords, como "de"
nltk.download('stopwords')
stop_words_spanish = list(stopwords.words('spanish'))


# In[51]:


# Extraemos los dos conjuntos de datos a estudiar
titles = [item['title'] for item in data]
bodies = [item['body'] for item in data]
# Necesitamos eliminar de bodies una cadena de barras bajas que no fui capaz de eliminar con la araña
bodies = [text.replace("__________________", "") for text in bodies]


# He creado una función para simplificar el estudio requerido de los dos campos de informacion, títulos y cuerpos

# In[63]:


def analyze_text(data):
    # Vectorizamos con TF-IDF, obviando las stopwords y los elementos que aparecen en menos de 10 doumentos
    vectorizerTfidf = TfidfVectorizer(stop_words=stop_words_spanish, min_df=10)
    tfidf_matrix = vectorizerTfidf.fit_transform(data)

    # Vectorizamos con TF obviando las stopwords
    vectorizerCount = CountVectorizer(stop_words=stop_words_spanish)
    count_matrix = vectorizerCount.fit_transform(data)

    # Obtenemos los 50 términos más "centrales" de la colección
    tfidf_sums = tfidf_matrix.sum(axis=0)
    tfidf_sorted_indices = tfidf_sums.argsort()[0, -50:][::-1]
    tfidf_top_terms = [vectorizerTfidf.get_feature_names_out()[i] for i in tfidf_sorted_indices]

    # Obtenemos los 100 términos más repetidos
    tf_sums = count_matrix.sum(axis=0)
    tf_sorted_indices = tf_sums.argsort()[0, -100:][::-1]
    tf_top_terms = [vectorizerCount.get_feature_names_out()[i] for i in tf_sorted_indices]

    print("50 términos más centrales:")
    print(tfidf_top_terms)
    print("\n100 términos más repetidos:")
    print(tf_top_terms)


# In[38]:


analyze_text(titles)


# In[42]:


analyze_text(bodies)


# Ahora volveremos a extraer los términos más relevantes mediante la técnica neuronal denominada BERT. Primero creo el modelo.

# In[24]:


from keybert import KeyBERT
kw_model = KeyBERT()


# In[45]:


# Extraemos los términos mas relevantes para cada documento de cada campo
keywordsTitles = kw_model.extract_keywords(titles)
keywordsBodies = kw_model.extract_keywords(bodies)


# In[64]:


# Esta función recibe las frecuencias extraidas con BERT para cada documento y realiza el global
def palabras_relevantes(keywords, stop_words, top_n=10):
    
    # Diccionario para almacenar las puntuaciones acumuladas
    keyword_scores = defaultdict(float)

    # Para cada lista de palabras clave (correspondiente a un documento)
    for doc_keywords in keywords:
        # Agrega la puntuación de cada palabra clave al total acumulado
        for keyword, score in doc_keywords:
            keyword_scores[keyword] += score

    # Ordena las palabras clave en función de sus puntuaciones acumuladas
    sorted_keywords = sorted(keyword_scores.items(), key=lambda x: x[1], reverse=True)

    # Filtrar las stopwords de la lista sorted_keywords
    filtered_keywords = [(keyword, score) for keyword, score in sorted_keywords if keyword.lower() not in stop_words]

    # Obtener el top_n
    return filtered_keywords[:top_n]


# In[61]:


# Para los titulos
top_10_titulos = palabras_relevantes(keywordsTitles, stop_words_spanish)
print(top_10_titulos)


# In[62]:


# Para los cuerpos
top_10_cuerpos = palabras_relevantes(keywordsBodies, stop_words_spanish)
print(top_10_cuerpos)


# Para finalizar vamos a usar WordCloud y Plotly para visualizar los resultados

# Empezamos creando un gráfico que representa las 100 palabras mas frecuentes, primero para los títulos y despues para los cuerpos

# In[56]:


import matplotlib.pyplot as plt
from wordcloud import WordCloud

# Creamos una funcion para simplificar el uso de WordCloud
def wordcloud_frecuencias(bodies, stop_words_spanish):
    # Primero eliminamos las stopwords del conjunto y preparamos los datos
    cleaned_bodies = []
    for body in bodies:
        cleaned_body = ' '.join([word for word in body.split() if word.lower() not in stop_words_spanish])
        cleaned_bodies.append(cleaned_body)
    full_text = ' '.join(cleaned_bodies)

    # Ahora configuramos WordCloud 
    wordcloud = WordCloud(
        stopwords=stop_words_spanish,  # Volvemos a indicar las stopwords
        background_color='white',      # Indicamos el color de fondo.
        width=800,                     # Indicamos el ancho de la imagen.
        height=800,                    # Indicamos el alto de la imagen.
        max_words=100                  # Indicamos el máximo de palabras a mostrar.
    ).generate(full_text)

    # Generamos la imagen
    plt.figure(figsize=(10, 10))
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis('off')
    plt.show()


# In[57]:


# Para los titulos
wordcloud_frecuencias(titles, stop_words_spanish)


# In[58]:


# Para los cuerpos
wordcloud_frecuencias(bodies, stop_words_spanish)


# Podemos ver como resaltan palabras relevantes a la addicción al juego como "juego", "ludopata" o "dinero"

# Ahora con Plotly vamos a crear una gráfica interactiva de las 20 palabras mas frecuentes, también primero para los titulos y despues para los cuerpos

# In[59]:


import plotly.express as px
from collections import Counter
from nltk.tokenize import word_tokenize
import pandas as pd

# El módulo PUNKT nos facilita la tokenización de los elementos
nltk.download('punkt')

def plot_frecuencia(bodies, stop_words, top_n=20):
    # Preparamos los datos, filtrando las stopwords
    all_text = ' '.join(bodies).lower()
    tokens = word_tokenize(all_text)
    filtered_tokens = [word for word in tokens if word not in stop_words and word.isalnum()]

    # Calculamos las frecuencias
    word_freq = Counter(filtered_tokens)

    # Convertimos los resultados en un DataFrame para el grafico
    df = pd.DataFrame(word_freq.most_common(top_n), columns=['Word', 'Frequency'])

    # Creamos el gráfico de barras interactivo con Plotly
    fig = px.bar(df, x='Word', y='Frequency', title=f"Top {top_n} palabras más frecuentes")
    fig.show()


# In[54]:


# Para los titulos
plot_frecuencia(titles, stop_words_spanish)


# In[55]:


# Para los cuerpos
plot_frecuencia(bodies, stop_words_spanish)

