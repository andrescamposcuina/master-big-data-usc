package gal.usc.etse.mbd.bdge.hbasetest;

import java.util.List;

/**
 * @author alumnogreibd
 */
public class practica5 {
    public static void main(String[] args) {
        testPostgresql();
        testInsercionHBase();
        testImpresion();
        testConsultaHBase();
        
        // E1:
        E1Pgsql();
        E1HBase();
        
        // E2:
        E2Pgsql();
        E2HBase();
        
        // E3:
        E3Pgsql();
        E3HBase();
        
        // E4:
        E4Pgsql();
        E4HBase();
        
        // E5:
        E5Pgsql();
        E5HBase();
    }

    private static void testPostgresql() {
        DAOPeliculas daop = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        List<Pelicula> pels = daop.getPeliculas(1000);
        pels.forEach(p -> {
            System.out.print(p.getIdPelicula() + ", " + p.getTitulo() + "\n");
        });
        daop.close();
    }

    private static void testInsercionHBase() {
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        List<Pelicula> pels = daopsql.getPeliculas(45433);
        DAOPeliculas daohbase = new DAOPeliculasHBase();

        pels.forEach(p -> {
            daohbase.insertaPelicula(p);
        });

        daopsql.close();
        daohbase.close();
    }

    private static void testConsultaHBase() {
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        List<Pelicula> pels = daohbase.getPeliculas(2);
        ImprimirPeliculas.imprimeTodo(pels);
        daohbase.close();
    }

    private static void testImpresion() {
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        List<Pelicula> pels = daopsql.getPeliculas(1);
        ImprimirPeliculas.imprimeTodo(pels);
        daopsql.close();
    }
    
    private static void E1Pgsql(){
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        Pelicula pel = daopsql.getPelicula(1865);
        ImprimirPeliculas.imprime(pel);
        daopsql.close();
    }
    
    private static void E1HBase(){
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        Pelicula pel = daohbase.getPelicula(1865);
        ImprimirPeliculas.imprime(pel);
        daohbase.close();
    }
    
    private static void E2Pgsql(){
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        List<Reparto> reparto = daopsql.getRepartoPorNombre("Avatar");
        System.out.println("Reparto de Avatar :");
        ImprimirPeliculas.imprimeReparto(reparto);
        daopsql.close();
    }
    
    private static void E2HBase(){
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        List<Reparto> reparto = daohbase.getRepartoPorNombre("Avatar");
        System.out.println("Reparto de Avatar :");
        ImprimirPeliculas.imprimeReparto(reparto);
        daohbase.close();
    }
    
    private static void E3Pgsql(){
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        List<Pelicula> peliculas = daopsql.getInfoPorPresupuesto(250000000);
        System.out.println("Info de las películas con más de " + 250000000 + " de presupuesto:");
        ImprimirPeliculas.imprimeInfo(peliculas);
        daopsql.close();
    }
    
    private static void E3HBase(){
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        List<Pelicula> peliculas = daohbase.getInfoPorPresupuesto(250000000);
        System.out.println("Info de las películas con más de " + 250000000 + " de presupuesto:");
        daohbase.close();
    }
    
    private static void E4Pgsql(){
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        daopsql.E4();
        daopsql.close();
    }
    
    private static void E4HBase(){
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        daohbase.E4();
        daohbase.close();
    }
    
    private static void E5Pgsql(){
        DAOPeliculas daopsql = new DAOPeliculasPgsql("localhost", "5432", "bdge", "alumnogreibd", "greibd2021");
        daopsql.E5();
        daopsql.close();
    }
    
    private static void E5HBase(){
        DAOPeliculas daohbase = new DAOPeliculasHBase();
        daohbase.E5();
        daohbase.close();
    }
}

